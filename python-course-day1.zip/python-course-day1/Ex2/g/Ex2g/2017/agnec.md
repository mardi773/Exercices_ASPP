Hi! I am a 1st year PhD student in Material Physics. Nice to meet you!
