phd-student at department of pharmacy. Not much experince with python except onlien tutorials. 

Albin is a big fan of Detroit Redwings.
