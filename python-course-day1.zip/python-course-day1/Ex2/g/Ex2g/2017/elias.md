modified!! ;)
PhD student at the Swedish Institute of Space Physics, Uppsala Office.
Working with analysis of data from the Rosetta spacecraft.
Currently participating in the course Advanced Scientific Programming with Python.
