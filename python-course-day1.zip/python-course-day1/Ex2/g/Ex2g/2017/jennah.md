Hello everyone! My name is Jennah and I'm a PhD student in Molecular Evolution (ICM). I'm from Canada...and also think mountains are cool? 
Hello, Jennah, nice to get to know you!
