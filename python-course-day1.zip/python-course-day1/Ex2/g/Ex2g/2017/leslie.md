Hello world!

My name is Leslie Solorzano. I am a computer scientist from Colombia. I made my master in France in Lyon. Currently I am a PhD Student at the IT department and I work on the Center for Image Analysis (CBA). My supervisor is Carolina Wählby. If you have images that you want to show us and collaborate, CBA is there to help you. You can see previous projects in the [CBA website](https://www.cb.uu.se) or in the [Wählby lab](http://www.cb.uu.se/~carolina/carolina_publications.html) website. 

![](https://webb.uu.se/image/full_image?img_id=72622657&t=1487020416500)
