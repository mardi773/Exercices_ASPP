blabla
some deep thoughts
