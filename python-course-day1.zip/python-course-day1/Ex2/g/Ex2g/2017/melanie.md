Hi, I am Melanie and work as researcher at the department of physics and astronomy. I do electron spectroscopy of clusters and molecules and I teach the atomic and molecular physics course.
Great to meet you!
