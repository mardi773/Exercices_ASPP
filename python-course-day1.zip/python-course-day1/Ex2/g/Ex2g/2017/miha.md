SGVsbG8gY3VyaW91cyBwZXJzb24sIEknbSBNaWhhIGFuZCBJIGxpa2UgUHl0aG9u\n
Base64 decoded by Paul
Hello curious person, I'm Miha and I like Python
