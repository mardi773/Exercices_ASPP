Hello!

My name is Andreas Röckert and I am a PhD student in the theoretical inorganic chemistry group at the Ångström laboratory. I like turtles.

I hope you have a great day!
