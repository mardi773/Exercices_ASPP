This is step 2. Create a new file
Write something about myself... I should then add this file to the files tracked by git
