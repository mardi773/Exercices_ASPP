Ageo Meier de Andrade, PhD student
