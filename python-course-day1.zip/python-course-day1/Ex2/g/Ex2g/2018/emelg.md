emelg
