Works at SciLifeLab LTS as an Application Expert.
That is an UPPMAX title, so I'm sort of in between.

Hej Jonas. Nu funkar GitHub för mig. /Kjell
