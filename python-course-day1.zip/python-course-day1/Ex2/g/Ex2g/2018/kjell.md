My name is Kjell Jorner and I am a computational chemist.
