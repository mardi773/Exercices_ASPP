That's file with info about me.


I am PhD student at Uppsala University. I am working with enzymes catalysis and dynamics as computational biochemist. 
