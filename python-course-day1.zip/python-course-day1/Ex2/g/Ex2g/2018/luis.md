	
	konnichiwa

