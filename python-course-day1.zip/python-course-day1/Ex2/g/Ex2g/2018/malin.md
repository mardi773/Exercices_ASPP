Hej,
my name is Malin and I am doing molecular dynamic simulations on transcription factors in the Kamerlin lab (ICM)
changed
