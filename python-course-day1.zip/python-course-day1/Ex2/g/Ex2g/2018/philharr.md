A big fan of Bach
