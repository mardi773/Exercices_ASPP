A PhD student in the department of Engineering Sciences at Uppsala University.
