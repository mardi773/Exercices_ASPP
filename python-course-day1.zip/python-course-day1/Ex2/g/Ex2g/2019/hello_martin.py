print('Hello Martin!')
