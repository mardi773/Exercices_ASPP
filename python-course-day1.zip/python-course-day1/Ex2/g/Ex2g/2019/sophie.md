
My name is Sophie Grape. I work with nuclear safeguards. 
