Hi I am Christina. I am a new PhD student in expertimental high energy physics.
