I am a geologist
I am also a rock scientist
