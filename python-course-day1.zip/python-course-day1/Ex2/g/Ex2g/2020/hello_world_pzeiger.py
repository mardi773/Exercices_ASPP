#!/usr/bin/env python3

# import some fancy but unnecessary stuff
import numpy as np

print('Hello World!')


