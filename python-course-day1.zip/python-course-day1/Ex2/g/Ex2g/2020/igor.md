My name is Igor Tominec, I come from Slovenia. I am a PhD student.
