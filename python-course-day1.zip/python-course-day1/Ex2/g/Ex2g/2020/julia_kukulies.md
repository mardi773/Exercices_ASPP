Hejhej! I am JUlia from the University of Gothenburg.

Hej Julia! I am Christina, nice to meet you. 
