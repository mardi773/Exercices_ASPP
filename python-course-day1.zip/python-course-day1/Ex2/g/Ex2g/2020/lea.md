My name is Lea, I am a PhD student in Chemical Engineering at KTH.

Nice to meet you! I'm Hanna. 
