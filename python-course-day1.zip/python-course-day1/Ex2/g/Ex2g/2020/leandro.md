# Leandro's markdown
Let's write a list of things to do:
- 1. Get the PhD
- 2. Find a cure for the Covid19
- 3. Unify the world
- 4. Dominate the world

Hey Leandro! Hope you make it. :) Rafael
