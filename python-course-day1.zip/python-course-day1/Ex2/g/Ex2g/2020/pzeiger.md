Hello world, please check out my beautiful program

