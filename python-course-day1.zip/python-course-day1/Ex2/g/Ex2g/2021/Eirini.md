Hello my name is Eirini and I am PhD studnet at the department of Enginerring Sciences. 


