I am PhD student at the division of systems and control, IT department. My research focus is machine learning methods.
