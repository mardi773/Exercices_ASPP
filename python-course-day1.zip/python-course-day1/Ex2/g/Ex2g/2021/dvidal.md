Hello, I'm David! I'm actually a master student doing an internship on cheminformatics. I am working with generative models of molecules!

Cheers!