Hello! I'm Felicia and I'm a second year PhD student. 
I work with molecular catalysts.
