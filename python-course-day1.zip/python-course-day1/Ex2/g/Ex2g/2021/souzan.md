Hello,
I'm Souzan Hammadi, 1st-year PhD student working on computational chemistry.
