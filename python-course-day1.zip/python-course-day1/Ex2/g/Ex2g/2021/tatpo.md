Tatiana PhD student Potapenko
 Division of Electricity
