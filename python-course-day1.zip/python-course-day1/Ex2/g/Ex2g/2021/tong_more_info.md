Hello, I am Tong and I am doing my PhD in machine learning applied to XFEL data. 
