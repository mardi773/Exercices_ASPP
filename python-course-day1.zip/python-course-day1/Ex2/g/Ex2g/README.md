Exercises for lecture on git
advanced Github!
>>>>>>> parent/master

Exercise 1g - Day 1 - Marcelo
