I am a PhD student at the department for cell and molecular biology. 

First edit. 

Second edit. 
