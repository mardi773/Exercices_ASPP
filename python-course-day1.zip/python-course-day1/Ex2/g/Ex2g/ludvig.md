Here's an empty markdown by Ludvig Larsson
