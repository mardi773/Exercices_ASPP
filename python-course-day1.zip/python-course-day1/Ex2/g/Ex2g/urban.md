Guarded by Sten Sture, I will work on speed optimization (I hope).
Getting up to speed... sort of.
