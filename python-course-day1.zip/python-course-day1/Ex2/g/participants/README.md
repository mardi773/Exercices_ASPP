# participants
Exercises for lecture on git
advanced Github!
