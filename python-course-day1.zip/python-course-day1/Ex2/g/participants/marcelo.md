Hey,

My name is Marcelo. I study Electrical Machines.


