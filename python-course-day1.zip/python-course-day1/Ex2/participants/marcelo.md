Hey,

My name is Marcelo. I study Electrical Machines.

Modification 1.d and 1.e

