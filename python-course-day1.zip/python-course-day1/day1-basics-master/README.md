# day1-basics
Lecture notes and code examples for Day 1: Basics
