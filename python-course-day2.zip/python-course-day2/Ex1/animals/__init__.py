#!/usr/bin/env python3

from animals.fish import Fish
from animals.mammals import Mammals
from animals.birds import Birds
