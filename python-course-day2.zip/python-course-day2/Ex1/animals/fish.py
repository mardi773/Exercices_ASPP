#!/usr/bin/env python3

#Class containing differen Fish
class Fish:
    def __init__(self):
        ''' Constructor for this class. '''
        #Creat some member animals
        self.members = ['Cod', 'Tuna', 'Sardine']

    def printMembers(self):
        print('Printing members of the Fish class')
        for member in self.members:
            print('\t%s ' % member)
#End of class