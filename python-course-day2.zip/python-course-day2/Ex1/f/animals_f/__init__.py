#!/usr/bin/env python3

from animals_f.dangerous.fish import Fish
from animals_f.mammals_f import Mammals
from animals_f.harmless.birds import Birds
