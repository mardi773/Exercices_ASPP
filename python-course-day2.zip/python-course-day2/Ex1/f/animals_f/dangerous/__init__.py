#!/usr/bin/env python3

from animals_f.dangerous.fish import Fish