#!/usr/bin/env python3

from animals_f.harmless.birds import Birds
