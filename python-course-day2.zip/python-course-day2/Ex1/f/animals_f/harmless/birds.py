#!/usr/bin/env python3

#Class containing different Birds
class Birds:
    def __init__(self):
        ''' Constructor for this class. '''
        #Creat some member animals
        self.members = ['Sparrow', 'Robin', 'Duck']

    def printMembers(self):
        print('Printing members of the Harmless Birds class')
        for member in self.members:
            print('\t%s ' % member)
#End of Class