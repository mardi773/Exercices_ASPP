#!/usr/bin/env python3

import animals_f

harmless_birds = animals_f.harmless.Birds()
harmless_birds.printMembers()

dangerous_fish = animals_f.dangerous.Fish()
dangerous_fish.printMembers()
