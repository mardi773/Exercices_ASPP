#!/usr/bin/env python3

import animals

f = animals.Fish()
f.printMembers()

m = animals.Mammals()
m.printMembers()

b = animals.Birds()
b.printMembers()
