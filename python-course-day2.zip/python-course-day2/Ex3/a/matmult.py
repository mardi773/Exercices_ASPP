# Program to multiply two matrices using nested loops
import random
from memory_profiler import profile

N = 250

@profile
def MatrixX(N):
# NxN matrix
    X = []
    for i in range(N):
        X.append([random.randint(0,100) for r in range(N)])
    return X

@profile
def MatrixY(N):
# Nx(N+1) matrix
    Y = []
    for i in range(N):
        Y.append([random.randint(0,100) for r in range(N+1)])
    return Y

@profile
def PreResult(N):
# result is Nx(N+1)
    result = []
    for i in range(N):
        result.append([0] * (N+1))
    return result

@profile
def Calc(X, Y, result):
# iterate through rows of X
    for i in range(len(X)):
    # iterate through columns of Y
        for j in range(len(Y[0])):
        # iterate through rows of Y
            for k in range(len(Y)):
                result[i][j] += X[i][k] * Y[k][j]
    return result

X = MatrixX(N)
Y = MatrixY(N)
result = PreResult(N)
result = Calc(X, Y, result)

for r in result:
    print(r)
