# Program to multiply two matrices using nested loops
import numpy as np
from memory_profiler import profile

N = 250

@profile
def MatrixX(N):
    X = np.random.randint(0, 101, (N, N))
    return X

@profile
def MatrixY(N):
    Y = np.random.randint(0, 101, (N, N))
    return Y

@profile
def CalcR(X,Y):
    result = X.dot(Y)
    return result

X = MatrixX(N)
Y = MatrixY(N)
result = CalcR(X,Y)

print(result)