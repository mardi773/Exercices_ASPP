# day2-bestpractices-1
Lecture notes and code examples for Day 2: Best practices 1
