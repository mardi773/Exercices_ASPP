from classroom.person import Student

me = Student('Benedikt', 'Daurer', 'physics')
me.printNameSubject()
