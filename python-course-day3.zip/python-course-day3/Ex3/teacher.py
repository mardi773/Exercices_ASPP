from classroom.person import Teacher

me = Teacher('John', 'Conway', 'Python programming')
me.printNameSubject()
