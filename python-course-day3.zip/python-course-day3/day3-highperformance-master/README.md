# day3-highperformance
Lecture notes and code examples for Day 3: High performance computing
