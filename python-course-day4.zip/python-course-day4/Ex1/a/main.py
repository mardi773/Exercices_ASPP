

import primes
import cy_primes

primes.primes(2000)
cy_primes.primes(2000)