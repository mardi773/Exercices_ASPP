from mpi4py import MPI


comm = MPI.COMM_WORLD
i = 0
while  (i < 6):
    rank = comm.Get_rank()
    print("Hello World from process", rank)
    i += 1