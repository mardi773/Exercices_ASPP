from mpi4py import MPI


comm = MPI.COMM_WORLD
rank = comm.Get_rank()

sumrank = 0

if rank != 0:
    sumrank += rank

if rank == 0:
    print("Process", rank, ": the sum over all the other ranks are ->", sumrank)