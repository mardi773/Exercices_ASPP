import numpy as np
import matplotlib.pyplot as plt

i = 0
while (i < 60):
    bg =np.random.randint(0,100, size=(100,100) )
    plt.imshow(bg, cmap='gray')
    plt.axis(False)
    plt.show(block=False)
    plt.pause(0.01)
    plt.clf()
    i += 1

plt.close()