import simple_math

def test_simple_math():
    assert simple_math.simple_add(1,2) == 3
    assert simple_math.simple_sub(2,1) == 1
    assert simple_math.simple_mult(2,2) == 4
    assert simple_math.simple_div(2,1) == 2
    assert simple_math.poly_first(1,2,3) == 5
    assert simple_math.poly_second(1,2,3,4) == 9