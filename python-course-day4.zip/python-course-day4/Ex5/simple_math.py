"""
A collection of simple math operations
"""

def simple_add(a,b):
    """The sum of two numbers

    Parameters
    ----------
    a, b : int, float
           The function will return the sum of this two parameters

    Returns
    -------
    int, float
           The value of the sum of a and b
    """
    return a+b

def simple_sub(a,b):
    """Subtracts b from a

    Parameters
    ----------
    a : int, float
           The original value, to which is pretended to subtract
    b : int, float
           The value to subtract from a
    Returns
    -------
    int, float
           The value of subtract a from b
    """
    return a-b

def simple_mult(a,b):
    return a*b

def simple_div(a,b):
    return a/b

def poly_first(x, a0, a1):
    return a0 + a1*x

def poly_second(x, a0, a1, a2):
    return poly_first(x, a0, a1) + a2*(x**2)

# Feel free to expand this list with more interesting mathematical operations...
# .....
