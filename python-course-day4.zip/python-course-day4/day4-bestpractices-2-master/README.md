# day4-bestpractices-2
Lecture notes and code examples for Day 4: Best practices 2
