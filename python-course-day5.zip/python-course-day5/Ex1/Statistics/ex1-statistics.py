from scipy import stats
import matplotlib.pyplot as plt
import numpy as np

np.random.seed(12345678)

#"""
#a. Create a discrete random variable with poissonian distribution and plot its probability mass function (PMF), 
#cummulative distribution function (CDF) and a histogram of 1000 random realizations of the variable.
#"""
#mu = 2

#x = np.arange(stats.poisson.ppf(0.01, mu), stats.poisson.ppf(0.99, mu))

##plot of Probability Mass Function (PMF)
#y = stats.poisson.pmf(x, mu)
#plt.plot(x, y, 'r')
#plt.title('Probability Mass Function (PMF), Poissonian')
#plt.show()
#plt.pause(0.5)
#plt.clf()

##plot of Cumulative Distribution Function (CDF)
#y = stats.poisson.cdf(x, mu)
#plt.plot(x, y, 'b')
#plt.title('Cumulative Distribution Function (CDF), Poissonian')
#plt.show()
#plt.pause(0.5)
#plt.clf()

##plot of a Histogram of 1000 random realizations of the Variable
#N_points = 1000
#n_bins = 10

#x = np.random.randint(stats.poisson.ppf(0.01, mu), stats.poisson.ppf(0.99, mu), size=N_points)
#y = stats.poisson.rvs(x, mu)
#print(y)
#print(x)
#plt.hist(y, bins=n_bins)
#plt.title('Histogram of 1000 random realizations of the Variable, Poissonian')
#plt.show()
#plt.pause(0.5)
#plt.clf()

#"""
#b. Create a continious random variable with normal distribution and plot its probability mass function (PMF), 
#cummulative distribution function (CDF) and a histogram of 1000 random realizations of the variable.
#"""

#x = np.linspace(stats.norm.ppf(0.01), stats.norm.ppf(0.99), 100)

##plot of Probability Density Function (PDF)
#y = stats.norm.pdf(x)
#plt.plot(x, y, 'r')
#plt.title('Probability Density Function (PDF), Normal')
#plt.show()
#plt.pause(0.5)
#plt.clf()

##plot of Cumulative Distribution Function (CDF)
#y = stats.norm.cdf(x)
#plt.plot(x, y, 'b')
#plt.title('Cumulative Distribution Function (CDF), Normal')
#plt.show()
#plt.pause(0.5)
#plt.clf()

##plot of a Histogram of 1000 random realizations of the Variable
#N_points = 1000
#n_bins = 10

#x = np.random.randint(stats.norm.ppf(0.01), high=stats.norm.ppf(0.99), size=N_points)
#y = stats.norm.rvs(x)
#print(y)
#print(x)
#plt.hist(y, bins=n_bins)
#plt.title('Histogram of 1000 random realizations of the Variable, Normal')
#plt.show()
#plt.pause(2)
#plt.close()

"""
c. Test if two sets of (independent) random data comes from the same distribution
"""
n_bins = 10
x = np.linspace(-5, 5, 500)
x1 = np.linspace(stats.norm.ppf(0.01), stats.norm.ppf(0.99), 500)

rvs1 = stats.norm.rvs(loc=5,scale=10,size=500)
rvs2 = stats.norm.rvs(loc=5,scale=10,size=500)

stats.ttest_ind(rvs1,rvs2)
stats.ttest_ind(rvs1,rvs2, equal_var = False)

mean = stats.ttest_ind(rvs1,rvs2)
print(stats.ttest_ind(rvs1,rvs2))

norm1 = stats.norm.pdf(x)
norm1 = norm1 * 100
x11 = x1 + mean[0]
norm2 = stats.norm.pdf(x)
x21 = x1 + mean[1]
norm2 = norm2 * 100

plt.plot(x, rvs1, 'r')
plt.plot(x, rvs2, 'b')
plt.show()
plt.plot(x11, norm1)
plt.hist(rvs1, bins=n_bins)
plt.show()
plt.plot(x21, norm2)
plt.hist(rvs2, bins=n_bins)
plt.show()
