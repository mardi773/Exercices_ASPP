import scipy as sc
import numpy as np

A = np.arange(9)
A = A.reshape(3,3)
A += 1

b = np.array([1,2,3])