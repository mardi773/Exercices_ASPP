import numpy as np
import scipy
import scipy.linalg as linalg
from scipy import stats

"""
Define matrix A

The original matrix A is singular, and because of that is not possible to solve A x = b.
But if I set an alternative matrix A (Aa) the rest of the code does what it is supose to do.
"""
A = np.arange(9)
A = A.reshape(3,3)
A += 1
Aa = np.array([[1,1,0], [0,1,0], [1,0,1]])

# Define vector b
b = np.array([1,2,3])

# Solve the equation A x = b 
#x = linalg.solve(A,b)
x = linalg.solve(Aa,b)

# Check the results
#b = np.matmul(A, x)
b2 = np.matmul(Aa, x)
print(b)
print(b2)

#e. repeat steps a-d using random 3x3 matrix B
#Matrix A (defined previous) is singular. So I will define a new random matrix A
A = np.random.randint(0,10,(3,3))
#new matrix B
B = np.random.randint(0,10,(3,3))

#solve the system A x = B
x = linalg.inv(A).dot(B)
print(x)

#check the new solution
B2 = np.matmul(A, x)
print(B)
print(B2)