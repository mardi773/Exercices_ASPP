import numpy as np
import scipy
import scipy.linalg as linalg
from scipy import stats

"""
Define matrix A

The original matrix A is singular, and because of that is not possible to solve A x = b. It is not possible to calculate the inverse of a matrix.
But if I set an alternative matrix A (Aa) the rest of the code does what it is supose to do.
"""
A = np.arange(9)
A = A.reshape(3,3)
A += 1
Aa = np.array([[1,1,0], [0,1,0], [1,0,1]])

#f.  Solve the eigenvalue problem for the matrix A and print the eigenvalues and eigenvectors
Aeigvals = linalg.eigvals(A)
print(Aeigvals)
Aeig = linalg.eig(A)
print(Aeig[1])

#g. Calculate the inverse, determinant of A
Aainv = linalg.inv(Aa)
#Ainv = linalg.inv(A)
#print(Ainv)
Adet = linalg.det(A)
print(Aainv)
print(Adet)

#h. Calculate the norm of A with different orders
Anorm = linalg.norm(A)
print(Anorm)




