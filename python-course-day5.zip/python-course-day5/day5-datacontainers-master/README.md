# day5-datacontainers
Lecture notes and code examples for Day 5: Data containers
